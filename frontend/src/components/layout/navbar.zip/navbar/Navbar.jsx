import { Bot } from "lucide-react";
import { NavLink } from "react-router-dom";

const links = [
  {
    label: "Home",
    to: "/",
  },
  {
    label: "Products",
    to: "/products",
  },
  {
    label: "Categories",
    to: "/categories",
  },
  {
    label: "Deals",
    to: "/deals",
  },
];

export default function DesktopNav() {
  return (
    <div className="hidden shrink-0 items-center gap-6 lg:flex">
      {links.map((link) => (
        <NavLink
          key={link.to}
          to={link.to}
          end={link.to === "/"}
          className={({ isActive }) =>
            `relative flex h-16 items-center text-sm font-medium transition-colors ${
              isActive
                ? "text-emerald-600"
                : "text-slate-700 hover:text-emerald-600 dark:text-slate-300 dark:hover:text-emerald-400"
            }`
          }
        >
          {({ isActive }) => (
            <>
              {link.label}

              {isActive && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-emerald-600" />
              )}
            </>
          )}
        </NavLink>
      ))}

      <NavLink
        to="/ai-assistant"
        className={({ isActive }) =>
          `flex h-16 shrink-0 items-center gap-1.5 text-sm font-medium transition-colors ${
            isActive
              ? "text-emerald-600"
              : "text-slate-700 hover:text-emerald-600 dark:text-slate-300 dark:hover:text-emerald-400"
          }`
        }
      >
        <Bot size={16} />
        <span>AI Assistant</span>
      </NavLink>
    </div>
  );
}