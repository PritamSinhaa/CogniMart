import { Heart, ShoppingCart, User } from "lucide-react";

const actions = [
  {
    label: "Wishlist",
    icon: Heart,
    href: "/wishlist",
  },
  {
    label: "Cart",
    icon: ShoppingCart,
    href: "/cart",
    badge: 2,
  },
  {
    label: "Login",
    icon: User,
    href: "/login",
  },
];

export default function NavbarActions() {
  return (
    <div className="hidden items-center gap-4 lg:flex">
      {actions.map(({ label, icon: Icon, href, badge }) => (
        <a
          key={label}
          href={href}
          className="group relative flex items-center gap-1.5 whitespace-nowrap text-xs font-medium text-slate-600 transition-colors hover:text-emerald-600 dark:text-slate-300 dark:hover:text-emerald-400"
        >
          <Icon
            size={16}
            className="transition-transform duration-200 group-hover:-translate-y-0.5"
          />

          {label}

          {badge > 0 && (
            <span className="absolute -right-2.5 -top-2 flex h-3.5 min-w-3.5 items-center justify-center rounded-full bg-emerald-600 px-1 text-[8px] font-bold text-white">
              {badge}
            </span>
          )}
        </a>
      ))}
    </div>
  );
}
